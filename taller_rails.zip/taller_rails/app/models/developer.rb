class Developer < ApplicationRecord
  belongs_to :project
end
